document.addEventListener('DOMContentLoaded', () => {
    // العناصر
    const websiteUrlInput = document.getElementById('websiteUrl');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const siteInfo = document.getElementById('siteInfo');
    const siteTitle = document.getElementById('siteTitle');
    const siteDescription = document.getElementById('siteDescription');
    const appCustomization = document.getElementById('appCustomization');
    const appNameInput = document.getElementById('appName');
    const appDescriptionInput = document.getElementById('appDescription');
    const uploadIconBtn = document.getElementById('uploadIconBtn');
    const iconUpload = document.getElementById('iconUpload');
    const iconPreview = document.querySelector('.icon-preview');
    const createAppBtn = document.getElementById('createAppBtn');
    const result = document.getElementById('result');
    const downloadMessage = document.getElementById('downloadMessage');
    const downloadLink = document.getElementById('downloadLink');
    const newAppBtn = document.getElementById('newAppBtn');
    const notification = document.getElementById('notification');
    const notificationMessage = document.getElementById('notificationMessage');

    // متغيرات الحالة
    let currentSiteData = null;
    let selectedIcon = null;
    let isProcessing = false;

    // تهيئة القيمة الافتراضية
    websiteUrlInput.value = 'https://';

    // تحليل الموقع
    analyzeBtn.addEventListener('click', async () => {
        const url = websiteUrlInput.value.trim();
        
        if (!url || url === 'https://') {
            showNotification('الرجاء إدخال رابط الموقع', 'error');
            websiteUrlInput.focus();
            return;
        }

        // تحقق من صحة الرابط
        try {
            new URL(url);
        } catch (e) {
            showNotification('الرجاء إدخال رابط صحيح (مثال: https://example.com)', 'error');
            return;
        }

        // إظهار التحميل
        analyzeBtn.disabled = true;
        loadingIndicator.classList.remove('hidden');
        siteInfo.classList.add('hidden');
        appCustomization.classList.add('hidden');
        result.classList.add('hidden');

        try {
            const response = await fetch('/api/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ url })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'حدث خطأ في تحليل الموقع');
            }

            // حفظ بيانات الموقع
            currentSiteData = data;
            
            // عرض معلومات الموقع
            siteTitle.textContent = data.title || new URL(url).hostname;
            siteDescription.textContent = data.description || 'تم تحليل الموقع بنجاح';
            
            // تعيين اسم التطبيق الافتراضي
            appNameInput.value = data.title || new URL(url).hostname;
            
            // إظهار المعلومات
            siteInfo.classList.remove('hidden');
            appCustomization.classList.remove('hidden');
            
            showNotification('تم تحليل الموقع بنجاح', 'success');
            
            // تمرير سلس
            appCustomization.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
        } catch (error) {
            showNotification(error.message, 'error');
        } finally {
            analyzeBtn.disabled = false;
            loadingIndicator.classList.add('hidden');
        }
    });

    // رفع الأيقونة
    uploadIconBtn.addEventListener('click', () => {
        iconUpload.click();
    });

    iconUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                showNotification('حجم الملف يجب أن يكون أقل من 5 ميجابايت', 'error');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                selectedIcon = e.target.result;
                iconPreview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 0.75rem;">`;
            };
            reader.readAsDataURL(file);
        }
    });

    // إنشاء التطبيق
    createAppBtn.addEventListener('click', async () => {
        if (isProcessing) return;
        
        const url = websiteUrlInput.value.trim();
        const appName = appNameInput.value.trim();
        const appDescription = appDescriptionInput.value.trim();

        if (!url || url === 'https://') {
            showNotification('الرجاء إدخال رابط الموقع', 'error');
            return;
        }

        if (!appName) {
            showNotification('الرجاء إدخال اسم التطبيق', 'error');
            appNameInput.focus();
            return;
        }

        isProcessing = true;
        createAppBtn.disabled = true;
        createAppBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري إنشاء التطبيق...';

        try {
            const response = await fetch('/api/create-app', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    url,
                    name: appName,
                    description: appDescription || `تطبيق ${appName}`,
                    icon: selectedIcon
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'حدث خطأ في إنشاء التطبيق');
            }

            // إظهار نتيجة التحميل
            appCustomization.classList.add('hidden');
            result.classList.remove('hidden');
            
            downloadMessage.textContent = `تم إنشاء تطبيق ${appName} بنجاح!`;
            downloadLink.href = data.downloadUrl;
            downloadLink.download = `${appName}-app.zip`;
            
            showNotification('تم إنشاء التطبيق بنجاح!', 'success');
            
        } catch (error) {
            showNotification(error.message, 'error');
            appCustomization.classList.remove('hidden');
        } finally {
            isProcessing = false;
            createAppBtn.disabled = false;
            createAppBtn.innerHTML = '<i class="fas fa-magic"></i> إنشاء التطبيق الآن<span class="btn-badge">مجاناً</span>';
        }
    });

    // إنشاء تطبيق جديد
    newAppBtn.addEventListener('click', () => {
        // إعادة تعيين النموذج
        websiteUrlInput.value = 'https://';
        appNameInput.value = '';
        appDescriptionInput.value = '';
        selectedIcon = null;
        iconPreview.innerHTML = '<i class="fas fa-image"></i>';
        
        // إخفاء النتائج
        siteInfo.classList.add('hidden');
        appCustomization.classList.add('hidden');
        result.classList.add('hidden');
        
        // تمرير إلى الأعلى
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        showNotification('يمكنك البدء من جديد', 'info');
    });

    // إظهار الإشعارات
    function showNotification(message, type = 'info') {
        notificationMessage.textContent = message;
        notification.classList.remove('hidden');
        
        // تغيير لون الإشعار حسب النوع
        const icon = notification.querySelector('i');
        if (type === 'success') {
            icon.style.color = 'var(--success)';
        } else if (type === 'error') {
            icon.style.color = 'var(--danger)';
        } else {
            icon.style.color = 'var(--primary)';
        }
        
        setTimeout(() => {
            notification.classList.add('hidden');
        }, 5000);
    }

    // التمرير إلى الأعلى
    window.scrollToTop = function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    // القائمة المتنقلة
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuBtn.addEventListener('click', () => {
        navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
    });

    // تحسين تجربة المستخدم للرابط
    websiteUrlInput.addEventListener('focus', () => {
        if (websiteUrlInput.value === 'https://') {
            websiteUrlInput.setSelectionRange(8, 8);
        }
    });

    // دعم زر Enter
    websiteUrlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            analyzeBtn.click();
        }
    });

    // تحميل أمثلة سريعة
    const examples = ['youtube.com', 'google.com', 'twitter.com', 'facebook.com'];
    let currentExample = 0;
    
    setInterval(() => {
        if (!websiteUrlInput.matches(':focus')) {
            websiteUrlInput.placeholder = `مثال: https://${examples[currentExample]}`;
            currentExample = (currentExample + 1) % examples.length;
        }
    }, 3000);

    console.log('✅ الموقع جاهز للعمل!');
});