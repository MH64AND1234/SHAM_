const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const { v4: uuidv4 } = require('uuid');
const { exec } = require('child_process');
const fetch = require('node-fetch');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static('public'));
app.use('/downloads', express.static(path.join(__dirname, 'downloads')));

// مجلدات التخزين
const TEMPLATES_DIR = path.join(__dirname, 'templates');
const DOWNLOADS_DIR = path.join(__dirname, 'downloads');

// تأكد من وجود المجلدات
fs.ensureDirSync(TEMPLATES_DIR);
fs.ensureDirSync(DOWNLOADS_DIR);

// قالب تطبيق Electron
const electronTemplate = (websiteUrl, appName, appIcon) => {
  return `const { app, BrowserWindow, Menu, shell, Tray, nativeImage } = require('electron');
const path = require('path');
const url = require('url');

let mainWindow;
let tray = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    title: '${appName}',
    icon: __dirname + '/icon.ico',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webviewTag: true,
      webSecurity: true
    },
    show: false,
    autoHideMenuBar: true
  });

  // تحميل الموقع
  mainWindow.loadURL('${websiteUrl}');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // فتح الروابط الخارجية في المتصفح الافتراضي
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.includes('${new URL(websiteUrl).hostname}')) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // إنشاء قائمة التطبيق
  const menuTemplate = [
    {
      label: 'ملف',
      submenu: [
        {
          label: 'الصفحة الرئيسية',
          click: () => {
            mainWindow.loadURL('${websiteUrl}');
          }
        },
        {
          label: 'تحديث الصفحة',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            mainWindow.reload();
          }
        },
        {
          label: 'تكبير',
          accelerator: 'CmdOrCtrl+=',
          click: () => {
            mainWindow.webContents.setZoomLevel(mainWindow.webContents.getZoomLevel() + 0.5);
          }
        },
        {
          label: 'تصغير',
          accelerator: 'CmdOrCtrl+-',
          click: () => {
            mainWindow.webContents.setZoomLevel(mainWindow.webContents.getZoomLevel() - 0.5);
          }
        },
        { type: 'separator' },
        {
          label: 'خروج',
          accelerator: 'CmdOrCtrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'عرض',
      submenu: [
        {
          label: 'إعادة تحميل',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            mainWindow.reload();
          }
        },
        {
          label: 'وضع ملء الشاشة',
          accelerator: 'F11',
          click: () => {
            mainWindow.setFullScreen(!mainWindow.isFullScreen());
          }
        },
        {
          label: 'أدوات المطور',
          accelerator: 'CmdOrCtrl+Shift+I',
          click: () => {
            mainWindow.webContents.openDevTools();
          }
        }
      ]
    },
    {
      label: 'مساعدة',
      submenu: [
        {
          label: 'عن التطبيق',
          click: () => {
            const { dialog } = require('electron');
            dialog.showMessageBox({
              type: 'info',
              title: 'عن التطبيق',
              message: '${appName}',
              detail: 'تم تحويل الموقع إلى تطبيق سطح مكتب\\nالموقع الأصلي: ${websiteUrl}',
              buttons: ['حسناً']
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});`;
};

// نقطة نهاية لتحليل الموقع
app.post('/api/analyze', async (req, res) => {
  try {
    const { url } = req.body;
    
    if (!url) {
      return res.status(400).json({ error: 'الرجاء إدخال رابط الموقع' });
    }

    // تحقق من صحة الرابط
    try {
      new URL(url);
    } catch (e) {
      return res.status(400).json({ error: 'رابط غير صحيح' });
    }

    // محاولة جلب معلومات الموقع
    let siteInfo = {
      title: new URL(url).hostname,
      description: 'تطبيق تم تحويله من موقع ويب',
      icon: null
    };

    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 5000
      });
      
      const html = await response.text();
      
      // استخراج العنوان
      const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
      if (titleMatch) {
        siteInfo.title = titleMatch[1].trim();
      }

      // استخراج الوصف
      const descMatch = html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)["'][^>]*>/i) ||
                       html.match(/<meta[^>]*property=["']og:description["'][^>]*content=["']([^"']+)["'][^>]*>/i);
      if (descMatch) {
        siteInfo.description = descMatch[1];
      }

      // استخراج الأيقونة
      const iconMatch = html.match(/<link[^>]*rel=["'](?:shortcut )?icon["'][^>]*href=["']([^"']+)["'][^>]*>/i) ||
                       html.match(/<link[^>]*rel=["']apple-touch-icon["'][^>]*href=["']([^"']+)["'][^>]*>/i);
      
      if (iconMatch) {
        let iconUrl = iconMatch[1];
        if (iconUrl.startsWith('//')) {
          iconUrl = 'https:' + iconUrl;
        } else if (iconUrl.startsWith('/')) {
          const urlObj = new URL(url);
          iconUrl = urlObj.origin + iconUrl;
        }
        siteInfo.icon = iconUrl;
      }
    } catch (error) {
      console.log('لا يمكن جلب معلومات الموقع:', error);
    }

    res.json(siteInfo);
  } catch (error) {
    console.error('خطأ:', error);
    res.status(500).json({ error: 'حدث خطأ في تحليل الموقع' });
  }
});

// نقطة نهاية لإنشاء التطبيق
app.post('/api/create-app', async (req, res) => {
  try {
    const { url, name, description, icon } = req.body;
    
    if (!url || !name) {
      return res.status(400).json({ error: 'الرجاء إدخال جميع المعلومات المطلوبة' });
    }

    const appId = uuidv4();
    const appDir = path.join(DOWNLOADS_DIR, appId);
    fs.ensureDirSync(appDir);

    // إنشاء ملفات التطبيق
    const mainJsContent = electronTemplate(url, name, icon);
    fs.writeFileSync(path.join(appDir, 'main.js'), mainJsContent);

    // إنشاء package.json للتطبيق
    const appPackageJson = {
      name: name.toLowerCase().replace(/\s+/g, '-'),
      version: '1.0.0',
      description: description || `تطبيق ${name}`,
      main: 'main.js',
      author: 'Website to App Converter',
      license: 'MIT',
      dependencies: {
        'electron': '^27.0.0'
      },
      build: {
        appId: `com.webtool.${appId}`,
        productName: name,
        directories: {
          output: 'dist'
        },
        win: {
          target: 'nsis',
          icon: 'icon.ico'
        },
        mac: {
          target: 'dmg',
          icon: 'icon.icns'
        },
        linux: {
          target: 'AppImage',
          icon: 'icon.png'
        }
      }
    };

    fs.writeFileSync(path.join(appDir, 'package.json'), JSON.stringify(appPackageJson, null, 2));

    // إنشاء أيقونة افتراضية
    const defaultIcon = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAAtSURBVHic7cExAQAAAMKg9U9tCj+gAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAMVZAAB2q9PpQAAAABJRU5ErkJggg==', 'base64');
    fs.writeFileSync(path.join(appDir, 'icon.ico'), defaultIcon);
    fs.writeFileSync(path.join(appDir, 'icon.png'), defaultIcon);
    fs.writeFileSync(path.join(appDir, 'icon.icns'), defaultIcon);

    // إنشاء ملف README
    const readmeContent = `# ${name}

تطبيق سطح مكتب لموقع ${url}

## كيفية التثبيت

### Windows
1. افتح مجلد \`dist\`
2. شغل ملف \`${name} Setup.exe\`
3. اتبع التعليمات

### macOS
1. افتح مجلد \`dist\`
2. اسحب ملف \`${name}.app\` إلى مجلد التطبيقات

### Linux
1. افتح مجلد \`dist\`
2. شغل ملف \`${name}.AppImage\`
3. اجعله قابلاً للتنفيذ: \`chmod +x ${name}.AppImage\`

## المميزات
- واجهة نظيفة بدون شريط عنوان
- قائمة تطبيق كاملة
- دعم التكبير والتصغير
- فتح الروابط الخارجية في المتصفح
- وضع ملء الشاشة

## متطلبات النظام
- Windows 7 أو أحدث
- macOS 10.13 أو أحدث
- Linux (Ubuntu 18.04 أو أحدث)

تم الإنشاء باستخدام Website to App Converter
`;
    fs.writeFileSync(path.join(appDir, 'README.md'), readmeContent);

    // إنشاء ملف ZIP
    const zipPath = path.join(DOWNLOADS_DIR, `${name}-app.zip`);
    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    archive.pipe(output);
    archive.directory(appDir, false);
    await archive.finalize();

    // تنظيف المجلد المؤقت
    fs.removeSync(appDir);

    res.json({
      success: true,
      downloadUrl: `/downloads/${name}-app.zip`,
      appId: appId
    });

  } catch (error) {
    console.error('خطأ في إنشاء التطبيق:', error);
    res.status(500).json({ error: 'حدث خطأ في إنشاء التطبيق' });
  }
});

// نقطة نهاية لتحميل التطبيق
app.get('/api/download/:filename', (req, res) => {
  const filename = req.params.filename;
  const filepath = path.join(DOWNLOADS_DIR, filename);
  
  if (fs.existsSync(filepath)) {
    res.download(filepath);
  } else {
    res.status(404).json({ error: 'الملف غير موجود' });
  }
});

// تنظيف الملفات القديمة (كل ساعة)
setInterval(() => {
  const files = fs.readdirSync(DOWNLOADS_DIR);
  const now = Date.now();
  
  files.forEach(file => {
    const filepath = path.join(DOWNLOADS_DIR, file);
    const stats = fs.statSync(filepath);
    const age = now - stats.mtimeMs;
    
    // حذف الملفات الأقدم من ساعة
    if (age > 3600000) {
      fs.removeSync(filepath);
    }
  });
}, 3600000);

app.listen(PORT, () => {
  console.log(`🚀 الخادم يعمل على http://localhost:${PORT}`);
});