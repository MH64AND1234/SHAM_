const chatbox=document.getElementById("chatbox");
let lastSend=0;
let memory=JSON.parse(localStorage.getItem("nova_memory")||"[]");

function addMsg(text,type="system"){
 const d=document.createElement("div");
 d.className="msg "+type;
 d.textContent=text;
 chatbox.appendChild(d);
 chatbox.scrollTop=chatbox.scrollHeight;
}

function compressContext(){
 let joined=memory.join("\n");
 if(joined.length>4000) joined=joined.slice(-4000);
 return joined;
}

function buildPrompt(userText){
 let mode=document.getElementById("mode").value;
 let persona=document.getElementById("persona").value;

 let p="أجب بنفس لغة المستخدم.\n";
 if(mode==="deep") p+="حلل بعمق.\n";
 if(mode==="creative") p+="كن إبداعيًا.\n";
 if(persona==="developer") p+="أنت مبرمج محترف.\n";
 if(persona==="teacher") p+="أنت مدرس.\n";
 if(persona==="security") p+="أنت خبير أمن.\n";

 p+="\nالسياق:\n"+compressContext()+"\n\n";
 p+="طلب المستخدم:\n"+userText;
 return p;
}

async function send(){
 if(Date.now()-lastSend<1500) return;
 lastSend=Date.now();

 let input=document.getElementById("input");
 let text=input.value.trim();
 if(!text) return;

 addMsg(text,"user");
 memory.push("USER:"+text);

 let typing=document.createElement("div");
 typing.className="typing";
 typing.textContent="Nova يفكر...";
 chatbox.appendChild(typing);

 let prompt=buildPrompt(text);
 let reply="⚠️ فشل الاتصال";

 try{
  const r=await fetch("https://api.novaapp.ai/api/chat/title/",{
   method:"POST",
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify({messages:[{role:"user",content:prompt}]})
  });
  const d=await r.json();
  reply=d.choices?.[0]?.message?.content||reply;
 }catch(e){}

 chatbox.removeChild(typing);
 addMsg(reply,"ai");
 memory.push("AI:"+reply);
 localStorage.setItem("nova_memory",JSON.stringify(memory));
 input.value="";
}

function clearChat(){
 chatbox.innerHTML="";
 memory=[];
 localStorage.clear();
}

function exportChat(){
 let blob=new Blob([memory.join("\n\n")],{type:"text/plain"});
 let a=document.createElement("a");
 a.href=URL.createObjectURL(blob);
 a.download="nova_chat.txt";
 a.click();
}

memory.forEach(m=>{
 addMsg(m.startsWith("USER:")?m.slice(5):m.slice(3),
 m.startsWith("USER:")?"user":"ai");
});
