Nova AI Engine

Project Structure:
- index.html (Main file)
- style.css (Design)
- script.js (Logic)
- README.txt

Upload all files together to your hosting.
